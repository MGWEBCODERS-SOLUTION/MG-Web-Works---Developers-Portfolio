MIT License

Copyright (c) 2025 MG Web Coders - Web Design and Digital Marketing

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

I. DEVELOPERS CONTACT DETAILS

facebook: https://www.facebook.com/share/17xNNwsc2C/
Whatsapp: +63 962-420-3788
Viber: +63 962-420-3788
Email: mgwebcoders@outlook.com

# MG Web Coders Inventory Management System

A web-based inventory management system for Business. This application helps manage products, customers, orders, and inventory levels.

## Features

- User authentication with role-based access (Admin, Sales, Staff)
- Product management with categories
- Customer management
- Order processing with status tracking
- Inventory management
- Responsive design for all devices


II. Login with the default credentials:
   - Admin: 
     - Username: admin
     - Password: admin
   - Sales:
     - Username: sales
     - Password: sales
   - Staff:
     - Username: staff
     - Password: staff
