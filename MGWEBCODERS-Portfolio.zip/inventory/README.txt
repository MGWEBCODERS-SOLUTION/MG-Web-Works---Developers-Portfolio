Please contact the developers to get SQL File and for more info.

ADMIN ACCESS
username: admin
password: admin

STAFF ACCESS
username: staff
password: staff

SALES ACCESS
username: sales
password: sales

DEVELOPERS CONTACT DETAILS

facebook: https://www.facebook.com/share/17xNNwsc2C/
Whatsapp: +63 962-420-3788
Viber: +63 962-420-3788
Email: mgwebcoders@outlook.com